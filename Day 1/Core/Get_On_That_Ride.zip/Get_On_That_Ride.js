
var height = 42 ;

var age = 10 ; 

/// if(height >= 42 && age >= 10 ){  
////    console.log("Get on that ride, kiddo!") ;

////}else { 
 ////   console,log("Sorry kiddo. Maybe next year.") ;
////} 

if ( height >= 42 || age >= 10 ){


    console.log("Get on that ride, kiddo!") ;
    
    } 
    else 
    {
        console,log("Sorry kiddo. Maybe next year.") ;
    
    
    }
